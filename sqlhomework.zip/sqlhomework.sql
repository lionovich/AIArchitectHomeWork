--1
SELECT 
    f.flight_id,
    f.flight_no,
    f.scheduled_departure,
    dep.airport_code AS departure_airport_code,
    dep.airport_name AS departure_airport_name
FROM 
    bookings.flights f
INNER JOIN 
    bookings.airports dep ON f.departure_airport = dep.airport_code;


SELECT 
    airport_code AS code,
    airport_name AS name
FROM 
    bookings.airports
UNION
SELECT 
    aircraft_code AS code,
    model AS name
FROM 
    bookings.aircrafts;
    
--2
   select scheduled_departure from bookings.flights
   
   SELECT 
    flight_id,
    flight_no,
    scheduled_departure,
    departure_airport,
    arrival_airport
FROM 
    bookings.flights
WHERE 
    scheduled_departure > '2016-09-19'
ORDER BY 
    scheduled_departure ASC
LIMIT 
    10;
   
--3
 SELECT
    f.flight_id,
    f.flight_no,
    COUNT(DISTINCT b.book_ref) AS total_bookings,
    MIN(b.total_amount) AS min_amount,
    MAX(b.total_amount) AS max_amount,
    SUM(tf.amount) AS total_revenue
FROM
    bookings.flights f
JOIN
    bookings.ticket_flights tf ON f.flight_id = tf.flight_id
JOIN
    bookings.tickets t ON tf.ticket_no = t.ticket_no
JOIN
    bookings.bookings b ON t.book_ref = b.book_ref
GROUP BY
    f.flight_id, f.flight_no
ORDER BY
    total_bookings DESC;
   
--4
-- INNER JOIN:
SELECT
    f.flight_id,
    f.flight_no,
    f.scheduled_departure,
    f.scheduled_arrival,
    a1.airport_name AS departure_airport_name,
    a2.airport_name AS arrival_airport_name
FROM
    bookings.flights f
INNER JOIN
    bookings.airports a1 ON f.departure_airport = a1.airport_code
INNER JOIN
    bookings.airports a2 ON f.arrival_airport = a2.airport_code;
   
-- LEFT JOIN:
   SELECT
    f.flight_id,
    f.flight_no,
    f.scheduled_departure,
    f.scheduled_arrival,
    a1.airport_name AS departure_airport_name,
    a2.airport_name AS arrival_airport_name
FROM
    bookings.flights f
LEFT JOIN
    bookings.airports a1 ON f.departure_airport = a1.airport_code
LEFT JOIN
    bookings.airports a2 ON f.arrival_airport = a2.airport_code;

--RIGHT JOIN:
   SELECT
    f.flight_id,
    f.flight_no,
    f.scheduled_departure,
    f.scheduled_arrival,
    a1.airport_name AS departure_airport_name,
    a2.airport_name AS arrival_airport_name
FROM
    bookings.airports a1
RIGHT JOIN
    bookings.flights f ON f.departure_airport = a1.airport_code
RIGHT JOIN
    bookings.airports a2 ON f.arrival_airport = a2.airport_code;

   
--5
CREATE OR REPLACE VIEW upcoming_flights AS
SELECT
    flight_id,
    flight_no,
    scheduled_departure,
    departure_airport,
    arrival_airport
FROM
    bookings.flights
WHERE
    scheduled_departure > '2016-09-19'
ORDER BY
    scheduled_departure ASC
LIMIT
    10;
   
   
