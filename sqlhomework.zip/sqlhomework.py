import psycopg2
from psycopg2 import sql
from prettytable import PrettyTable
conn = psycopg2.connect(
    dbname="demo",
    user="postgres",
    password="olongjohnson",
    host="localhost",
    port="5432"
)
cursor = conn.cursor()

query = sql.SQL("SELECT * FROM {}").format(sql.Identifier("upcoming_flights"))
cursor.execute(query)
results = cursor.fetchall()

table = PrettyTable()
table.field_names = [desc[0] for desc in cursor.description]

for row in results:
    table.add_row(row)

print(table)
cursor.close()
conn.close()